<?php
/**
 * Plugin Name: WooAdventure Integration
 * Description: Integração completa para Ecoturismo (Checkout, API Roca, Gestão de Participantes, Agenda e Assinaturas Digitais).
 * Version: 2.2.0
 * Author: Seu Nome
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// --- FUNÇÃO DE SEGURANÇA PARA CARREGAR ARQUIVOS ---
// Evita erro fatal se um arquivo estiver faltando
if ( ! function_exists( 'wcai_safe_require' ) ) {
    function wcai_safe_require( $filename ) {
        $path = plugin_dir_path( __FILE__ ) . 'includes/' . $filename;
        if ( file_exists( $path ) ) {
            require_once $path;
        } else {
            // Apenas registra no log silenciosamente, não quebra o site
            error_log( "[WCAI] Aviso: O arquivo $filename não foi encontrado na pasta includes." );
        }
    }
}

// 1. CARREGAMENTO DOS ARQUIVOS (Usando modo seguro)
wcai_safe_require( 'class-utils.php' );
wcai_safe_require( 'class-settings.php' );
wcai_safe_require( 'class-participants-db.php' );
wcai_safe_require( 'class-checkout.php' );
wcai_safe_require( 'class-order.php' );
wcai_safe_require( 'class-api-integration.php' );
wcai_safe_require( 'class-frontend-account.php' );

// Tenta carregar a Agenda.
wcai_safe_require( 'class-agenda.php' ); 

// [NOVO] Carrega o Módulo de Assinatura
wcai_safe_require( 'class-assinatura.php' );


// 2. INICIALIZAÇÃO DAS CLASSES
function wcai_init() {
    // Só inicia se a classe foi carregada com sucesso
    if ( class_exists( 'WCAI_Settings' ) ) { new WCAI_Settings(); }
    if ( class_exists( 'WCAI_Checkout' ) ) { new WCAI_Checkout(); }
    if ( class_exists( 'WCAI_Order' ) ) { new WCAI_Order(); }
    if ( class_exists( 'WCAI_API_Integration' ) ) { new WCAI_API_Integration(); }
    if ( class_exists( 'WCAI_Frontend_Account' ) ) { new WCAI_Frontend_Account(); }
    
    // Agenda
    if ( class_exists( 'WCAI_Agenda' ) ) { 
        new WCAI_Agenda(); 
    }

    // [NOVO] Inicia o Módulo de Assinatura
    if ( class_exists( 'WCAI_Assinatura' ) ) { 
        new WCAI_Assinatura(); 
    }
}
add_action( 'plugins_loaded', 'wcai_init' );


// 3. ATIVAÇÃO (Criação de Tabelas)
register_activation_hook( __FILE__, 'wcai_activate_plugin' );
function wcai_activate_plugin() {
    if ( class_exists( 'WCAI_Participants_DB' ) ) {
        WCAI_Participants_DB::create_table();
    }
    if ( class_exists( 'WCAI_API_Integration' ) ) {
        WCAI_API_Integration::create_tables();
    }
}