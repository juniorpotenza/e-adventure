<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCAI_Assinatura {

    public function __construct() {
        // 1. Painel Admin (CPT)
        add_action( 'init', array( $this, 'register_cpt' ) );
        add_filter( 'manage_wcai_assinatura_posts_columns', array( $this, 'set_custom_columns' ) );
        add_action( 'manage_wcai_assinatura_posts_custom_column', array( $this, 'custom_column_content' ), 10, 2 );
        add_action( 'add_meta_boxes', array( $this, 'add_details_metabox' ) );

        // 2. Shortcode (Apenas o Formulario)
        add_shortcode( 'wcai_painel_assinatura', array( $this, 'render_shortcode' ) );
        
        // --- NOVO: Shortcode que injeta o script de validação no documento do WP E-Signature ---
        add_shortcode( 'wcai_script_validacao', array( $this, 'render_validation_script_shortcode' ) );

        // 3. AJAX - Validações e Salvamento
        add_action( 'wp_ajax_wcai_check_order_only', array($this, 'ajax_check_order') );
        add_action( 'wp_ajax_nopriv_wcai_check_order_only', array($this, 'ajax_check_order') );
        
        add_action( 'wp_ajax_wcai_autocheck_pax', array($this, 'ajax_check_pax_deep') );
        add_action( 'wp_ajax_nopriv_wcai_autocheck_pax', array($this, 'ajax_check_pax_deep') );

        add_action( 'wp_ajax_wcai_salvar_assinatura_final', array( $this, 'ajax_save_signature' ) );
        add_action( 'wp_ajax_nopriv_wcai_salvar_assinatura_final', array( $this, 'ajax_save_signature' ) );
    }

    // =========================================================================
    // 1. SCRIPT DE VALIDAÇÃO (SEM ALERTS PARA EVITAR LOOP)
    // =========================================================================
    public function render_validation_script_shortcode() {
        // Nomes exatos do formulário
        $name_pedido = 'esig-sif-1739375553756';
        $name_cpf    = 'esig-sif-1739375595096';
        ob_start();
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            var ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
            var selPedido = 'input[name="<?php echo $name_pedido; ?>"]';
            var selCPF    = 'input[name="<?php echo $name_cpf; ?>"]';

            // 1. Validação do PEDIDO
            $(document).on('blur', selPedido, function() {
                var $this = $(this);
                var val = $this.val().trim();
                var $msg = $('#wcai-msg-pedido');

                // Se o campo estiver vazio, limpa a mensagem e sai
                if(val.length === 0) {
                    $msg.html('');
                    return;
                }

                $msg.html('<span style="color:#666">⌛ Verificando...</span>');
                
                $.post(ajaxUrl, { action:'wcai_check_order_only', order_id:val }, function(r){
                    if(r.success) {
                        $msg.html('<span style="color:green;font-weight:bold">✅ Pedido Encontrado!</span>');
                    } else {
                        // ERRO: Mostra mensagem vermelha e limpa o campo, SEM ALERT
                        $msg.html('<span style="color:red;font-weight:bold">❌ Pedido não encontrado. Digite novamente.</span>');
                        $this.val(''); 
                    }
                }).fail(function() { $msg.html('Erro de conexão.'); });
            });

            // 2. Validação do CPF
            $(document).on('blur', selCPF, function() {
                var $this = $(this);
                var val = $this.val().replace(/\D/g, ''); // Remove pontuação
                var ped = $(selPedido).val().trim();
                var $msg = $('#wcai-msg-cpf');

                // Se o campo CPF estiver vazio, não faz nada
                if(val.length === 0) return;

                // Se não preencheu o pedido ainda
                if(!ped) { 
                    $msg.html('<span style="color:orange;font-weight:bold">⚠️ Preencha o Nº do Pedido acima primeiro.</span>');
                    $this.val(''); 
                    return; 
                }

                $msg.html('<span style="color:#666">⌛ Buscando participante...</span>');
                
                $.post(ajaxUrl, { action:'wcai_autocheck_pax', order_id:ped, cpf:val }, function(r){
                    if(r.success) {
                        $msg.html('<span style="color:green;font-weight:bold">✅ Confirmado: ' + r.data.nome + '</span>');
                    } else {
                        // ERRO: Mostra mensagem vermelha e limpa o campo, SEM ALERT
                        $msg.html('<span style="color:red;font-weight:bold">❌ CPF não encontrado neste pedido.</span>');
                        $this.val(''); 
                    }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }

    // =========================================================================
    // 2. AJAX HELPERS (LÓGICA MANTIDA)
    // =========================================================================
    
    public function ajax_check_order() {
        $id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        if(wc_get_order($id)) wp_send_json_success(); 
        else wp_send_json_error();
    }

    public function ajax_check_pax_deep() {
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        $cpf_input = preg_replace('/\D/', '', isset($_POST['cpf']) ? $_POST['cpf'] : ''); 

        if ( !$order_id || !$cpf_input ) { wp_send_json_error('Dados incompletos'); return; }

        $order = wc_get_order($order_id);
        if ( !$order ) { wp_send_json_error('Pedido inválido'); return; }

        $found = false;
        $nome_encontrado = 'Participante';

        // --- VARREDURA COMPLETA ---

        // 1. Tabela DB
        if(class_exists('WCAI_Participants_DB')) {
            $db_pax = WCAI_Participants_DB::get_by_order($order_id);
            if(is_array($db_pax)) {
                foreach($db_pax as $p) {
                    if(preg_replace('/[^0-9]/','',$p['cpf']) === $cpf_input) {
                        $found = true; $nome_encontrado = $p['nome_completo']; break;
                    }
                }
            }
        }

        // 2. Metadados dos Itens
        if(!$found) {
            foreach($order->get_items() as $item) {
                foreach($item->get_meta_data() as $meta) {
                    if(!is_scalar($meta->value)) continue;
                    
                    $val_clean = preg_replace('/[^0-9]/', '', (string)$meta->value);
                    if($val_clean === $cpf_input && strlen($val_clean) >= 11) {
                        $found = true;
                        $nome_encontrado = $item->get_name();
                        foreach($item->get_meta_data() as $sub) {
                            if(is_string($sub->value) && (stripos($sub->key,'nome')!==false || stripos($sub->key,'name')!==false) && !is_numeric($sub->value)) {
                                $nome_encontrado = $sub->value; break;
                            }
                        }
                        break 2;
                    }
                }
            }
        }

        // 3. Billing
        if(!$found) {
            $b_cpf = preg_replace('/\D/', '', $order->get_meta('_billing_cpf') ?: $order->get_meta('billing_cpf'));
            if($b_cpf === $cpf_input) {
                $found = true;
                $nome_encontrado = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            }
        }

        // 4. Notas
        if(!$found) {
            $note = $order->get_customer_note();
            if(!empty($note) && strpos(preg_replace('/[^0-9]/','',$note), $cpf_input) !== false) {
                $found = true; $nome_encontrado = "Visitante (Nota)";
            }
        }

        if ( $found ) {
            setcookie('wcai_pax_session', $order_id.'|'.$cpf_input, time() + 3600, '/');
            wp_send_json_success( array( 'nome' => $nome_encontrado ) );
        } else {
            wp_send_json_error('CPF não vinculado a este pedido.');
        }
    }

    // =========================================================================
    // 3. FRONTEND: FORMULÁRIO (MANTIDO VAZIO OU ORIGINAL)
    // =========================================================================
    public function render_shortcode( $atts ) {
        return ''; 
    }

    // =========================================================================
    // 4. BACKEND: SALVAMENTO E EMAIL
    // =========================================================================
    public function ajax_save_signature() {
        $pedido_id = sanitize_text_field($_POST['pedido']);
        $cpf = sanitize_text_field($_POST['cpf']);
        $img_base64 = $_POST['assinatura'];

        if (empty($img_base64)) wp_send_json_error('Assinatura vazia.');

        $post_id = wp_insert_post([
            'post_type' => 'wcai_assinatura',
            'post_title' => "$cpf - Pedido $pedido_id",
            'post_status' => 'publish'
        ]);
        
        if (is_wp_error($post_id)) wp_send_json_error('Erro DB');

        $parts = explode(";base64,", $img_base64);
        $decoded = base64_decode(isset($parts[1]) ? $parts[1] : $img_base64);
        $filename = "assign_{$pedido_id}_{$post_id}.png";
        $upload = wp_upload_bits($filename, null, $decoded);

        if ($upload['error']) wp_send_json_error($upload['error']);

        update_post_meta($post_id, '_wcai_pedido_id', $pedido_id);
        update_post_meta($post_id, '_wcai_cpf_cliente', $cpf);
        update_post_meta($post_id, '_wcai_assinatura_url', $upload['url']);
        update_post_meta($post_id, '_wcai_ip', $_SERVER['REMOTE_ADDR']);
        update_post_meta($post_id, '_wcai_device', $_SERVER['HTTP_USER_AGENT']);
        update_post_meta($post_id, '_wcai_data_hora', current_time('mysql'));

        $this->send_audit_email($pedido_id, $cpf, $post_id, $upload['url'], $decoded);

        wp_send_json_success();
    }

    private function send_audit_email($pedido_id, $cpf, $doc_id, $img_url, $raw_data) {
        $order = wc_get_order($pedido_id);
        if(!$order) return;

        $order->add_order_note("Termo assinado ($cpf). ID DOC: $doc_id.");
        
        $to = get_option('admin_email');
        $subject = "Termo Assinado - Pedido #$pedido_id";
        
        $msg = "
        <html><body>
        <div style='font-family:Arial; color:#333;'>
            <h2 style='color:#007cba;'>Termo de Responsabilidade</h2>
            <p>O participante abaixo assinou digitalmente o termo disponível no site.</p>
            <div style='background:#f9f9f9; padding:15px; border:1px solid #eee; border-radius:5px;'>
                <p><strong>Participante (CPF):</strong> $cpf</p>
                <p><strong>Pedido Vinculado:</strong> #$pedido_id</p>
                <p><strong>Data da Assinatura:</strong> ".current_time('d/m/Y H:i:s')."</p>
            </div>
            <h3>Assinatura Digital</h3>
            <div style='border:1px solid #ccc; display:inline-block; padding:10px;'>
                <img src='$img_url' width='300'/>
            </div>
            <hr>
            <p style='font-size:10px; color:#999;'>
                <strong>Metadados de Segurança:</strong><br>
                IP: ".$_SERVER['REMOTE_ADDR']."<br>
                Device: ".$_SERVER['HTTP_USER_AGENT']."<br>
                Integridade (Hash): ".md5($raw_data . current_time('mysql'))."
            </p>
        </div>
        </body></html>
        ";
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($to, $subject, $msg, $headers);
        if($order->get_billing_email()) wp_mail($order->get_billing_email(), "Comprovante do seu Termo", $msg, $headers);
    }

    // =========================================================================
    // 4. ADMIN: VISUALIZAÇÃO (CPT)
    // =========================================================================
    public function register_cpt() {
        register_post_type('wcai_assinatura', array(
            'labels' => array('name' => 'Assinaturas', 'singular_name' => 'Assinatura'),
            'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_position' => 58, 'menu_icon' => 'dashicons-pen',
            'supports' => array('title'), 'capabilities' => array('create_posts' => false), 'map_meta_cap' => true
        ));
    }

    public function set_custom_columns($c) { return array_merge($c, ['pedido_ref'=>'Pedido', 'cpf_ref'=>'CPF']); }
    
    public function custom_column_content($c, $pid) {
        if($c=='pedido_ref') echo get_post_meta($pid, '_wcai_pedido_id', true);
        if($c=='cpf_ref') echo get_post_meta($pid, '_wcai_cpf_cliente', true);
    }

    public function add_details_metabox() { add_meta_box('wcai_sig_details', 'Detalhes', array($this,'render_metabox'), 'wcai_assinatura', 'normal', 'high'); }

    public function render_metabox($post) {
        $url = get_post_meta($post->ID, '_wcai_assinatura_url', true);
        $ip = get_post_meta($post->ID, '_wcai_ip', true);
        echo "<p><strong>IP:</strong> $ip</p>";
        echo $url ? "<img src='$url' style='max-width:300px; border:1px solid #ccc;'>" : "Sem imagem";
    }
}